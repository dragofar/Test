var clipboard1=new ClipboardJS('.main-button.copy');clipboard1.on('success',function(e)
{yaCounter46328574.reachGoal('copygta5');e.trigger.innerHTML="Скопировано";});